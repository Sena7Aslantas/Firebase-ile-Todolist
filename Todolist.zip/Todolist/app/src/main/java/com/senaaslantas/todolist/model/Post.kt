package com.senaaslantas.todolist.model

data class Post(val note:String,val date:String,val time:String) {
}